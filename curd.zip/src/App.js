import {BrowserRouter as Router,Routes,Route} from 'react-router-dom'
import Home from './Components/Pages/Home';
import { Navbar } from './Components/Common/Navbar';
import AllUsers from './Components/Pages/AllUsers';
import EditUser from './Components/Pages/EditUser';
import AddUser from './Components/Pages/AddUser';

function App() {
  return (
    <div>
      <Router>
        <Navbar/>
        <Routes>
          <Route path='/' element={<Home/>}/>
          <Route path='/All-Users' element={<AllUsers/>}/>
          <Route path='/Add-User' element={<AddUser/>}/>
          <Route path='/Edit-User/:id' element={<EditUser/>}/>
        </Routes>
      </Router>
    </div>
  );
}

export default App;
