import React,{ useEffect , useState } from "react";
import { getuser , deleteUser } from "../../Services/Api";
import { NavLink } from "react-router-dom";

export default function AllUsers() {
    const [user,setUser]=useState([])
    
    useEffect(()=>{
        getallUser()
    },[])
    
    const getallUser=async()=>{
        const response=await getuser()
        console.log(response.data);
        setUser(response.data)
    }

    const deleteuser=async(id)=>{
        await deleteUser(id)
        getallUser()
    }
    
  return (
    <div>
      <table class="table">
        <thead class="thead-dark">
          <tr>
            <th scope="col">ID</th>
            <th scope="col">Name</th>
            <th scope="col">Email</th>
            <th scope="col">Phone</th>
            <th scope="col">City</th>
            <th scope="col">Action</th>
          </tr>
        </thead>
        <tbody>
            {user.map((users)=>(
                <tr key={users.id}>
                <td>{users.id}</td>
                <td>{users.name}</td>
                <td>{users.email}</td>
                <td>{users.phone}</td>
                <td>{users.city}</td>
                <td>
                    <NavLink to={`/Edit-User/${users.id}`} className='btn btn-secondary'>Edit</NavLink>
        
                    <button onClick={()=>deleteuser(users.id)} className="btn btn-danger">Delete</button>
                </td>
              </tr>
            ))}
        </tbody>
      </table>
    </div>
  );
}
