import React,{useState} from "react";
import { adduser } from "../../Services/Api";
import {useNavigate} from 'react-router-dom'

const initialvalue={
    name:'',
    email:'',
    phone:'',
    city:''
}

export default function AddUser() {
    const navigate=useNavigate()
    
    const [user,setUser]=useState(initialvalue)
    
    const {name,email,phone,city}=user;
    
    const onValueChange=(e)=>{
        console.log(e.target.value);
        setUser({...user,[e.target.name]:e.target.value})
        console.log(user);
    }
    const adduserdetails=async()=>{
        await adduser(user)
        navigate('/')
    }
  return (
    <div>
      <form style={{width:"50%",margin:"5% 0 0 25%"}}>
      <div className="form-group">
          <label for="exampleInputName1">Name</label>
          <input
            name="name"
            onChange={(e)=>onValueChange(e)}
            value={name}
            type="text"
            className="form-control"
          />
        </div>
        <div className="form-group">
          <label for="exampleInputEmail1">Email address</label>
          <input
            name="email"
            onChange={(e)=>onValueChange(e)}
            value={email}
            type="email"
            className="form-control"           
          />
        </div>
        <div className="form-group">
          <label for="exampleInputPhone1">Phone</label>
          <input
            name="phone"
            onChange={(e)=>onValueChange(e)}
            value={phone}
            type="Number"
            className="form-control"            
          />
        </div>
        <div className="form-group">
          <label for="exampleInputCity1">City</label>
          <input
            name="city"
            onChange={(e)=>onValueChange(e)}
            value={city}
            type="text"
            className="form-control"
          />
        </div>
        <button type="submit" onClick={()=>adduserdetails()} className="btn btn-primary">
          Submit
        </button>
      </form>
    </div>
  );
}
